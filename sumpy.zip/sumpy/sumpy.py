a = int(input("Digit a number: "))

b = 1

print(a+b)
