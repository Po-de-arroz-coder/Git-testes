a = 20

b = 30

c = a+b
print(c)
