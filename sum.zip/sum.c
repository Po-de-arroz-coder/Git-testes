#include <stdio.h>

int main(){
	int a=0,b=0,c=0;
	
	a = 10;
	
	b = 20;
	
	c = a+b;
	
	printf("10 + 20 = %i \n",c);
	
	return 0;
}

